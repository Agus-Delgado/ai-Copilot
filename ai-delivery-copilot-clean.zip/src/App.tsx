// Re-export from app/App
export { App } from './app/App'
